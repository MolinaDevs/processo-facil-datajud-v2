
export default async function handler(req, res) {
  // Permitir CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  // Responder a requisições OPTIONS (preflight)
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  try {
    // Extrair a API key do header
    const apiKey = req.headers.authorization?.replace('APIKey ', '');
    
    if (!apiKey) {
      return res.status(401).json({ error: 'API Key não fornecida' });
    }

    // URL da API DataJud
    const apiUrl = 'https://api-publica.datajud.cnj.jus.br/api_publica_tjsp/_search';
    
    console.log('Fazendo requisição para:', apiUrl);
    console.log('Body da requisição:', JSON.stringify(req.body, null, 2));

    // Fazer a requisição para a API DataJud
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Authorization': `APIKey ${apiKey}`,
        'Content-Type': 'application/json',
        'User-Agent': 'Sistema-Consulta-Processual/1.0'
      },
      body: JSON.stringify(req.body)
    });

    console.log('Status da resposta:', response.status);
    console.log('Headers da resposta:', Object.fromEntries(response.headers.entries()));

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Erro da API DataJud:', {
        status: response.status,
        statusText: response.statusText,
        responseText: errorText.substring(0, 1000)
      });
      
      return res.status(response.status).json({
        error: `Erro da API DataJud: ${response.status} - ${response.statusText}`,
        details: errorText.substring(0, 200)
      });
    }

    // Verificar content-type
    const contentType = response.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) {
      const responseText = await response.text();
      console.error('Resposta não é JSON:', {
        contentType,
        responseText: responseText.substring(0, 1000)
      });
      
      return res.status(502).json({
        error: 'API retornou conteúdo inválido',
        contentType,
        response: responseText.substring(0, 200)
      });
    }

    // Retornar a resposta da API
    const data = await response.json();
    res.status(200).json(data);

  } catch (error) {
    console.error('Erro no proxy:', error);
    res.status(500).json({
      error: 'Erro interno do servidor',
      message: error.message
    });
  }
}
