
import { Scale, Target } from 'lucide-react';
import { ProcessSystem } from '@/components/ProcessSystem';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Scale className="h-12 w-12 text-blue-600 mr-3" />
            <h1 className="text-4xl font-bold text-gray-900">
              Sistema de Consulta Processual
            </h1>
          </div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Consulte processos jurídicos de forma rápida e eficiente através da API DataJud do CNJ
          </p>
          
          {/* Navigation */}
          <div className="mt-6">
            <Button 
              onClick={() => navigate('/anuncios')} 
              variant="outline"
              className="mr-4"
            >
              <Target className="h-4 w-4 mr-2" />
              Ver Anúncios Jurídicos
            </Button>
          </div>
        </div>

        <ProcessSystem />
      </div>
    </div>
  );
};

export default Index;
