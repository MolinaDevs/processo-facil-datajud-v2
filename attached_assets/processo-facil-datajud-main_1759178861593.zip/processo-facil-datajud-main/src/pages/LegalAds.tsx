
import { LegalAdsManager } from '@/components/LegalAdsManager';
import { Scale, Target } from 'lucide-react';

const LegalAds = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Target className="h-12 w-12 text-blue-600 mr-3" />
            <h1 className="text-4xl font-bold text-gray-900">
              Anúncios Jurídicos
            </h1>
          </div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Descubra as melhores soluções, cursos e serviços para profissionais do direito
          </p>
        </div>

        <LegalAdsManager />
      </div>
    </div>
  );
};

export default LegalAds;
