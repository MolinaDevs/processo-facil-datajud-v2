
import { useCallback } from 'react';

export const useGoogleAds = () => {
  const trackConversion = useCallback((value?: number, currency = 'BRL') => {
    if ((window as any).trackGoogleAdsConversion) {
      (window as any).trackGoogleAdsConversion(value, currency);
    }
  }, []);

  const trackEvent = useCallback((eventName: string, parameters?: any) => {
    if ((window as any).gtag) {
      (window as any).gtag('event', eventName, parameters);
    }
  }, []);

  return {
    trackConversion,
    trackEvent
  };
};
