
import { useState } from 'react';
import { ProcessData, ConsultationStats } from '@/types/process';
import { DataJudService } from '@/services/datajudApi';
import { toast } from '@/hooks/use-toast';

export const useProcessConsultation = () => {
  const [results, setResults] = useState<ProcessData[]>([]);
  const [loading, setLoading] = useState(false);
  const [consultationStats, setConsultationStats] = useState<ConsultationStats | undefined>(undefined);

  const convertDataJudToProcessData = (dataJudProcess: any): ProcessData => {
    console.log('Convertendo dados DataJud:', dataJudProcess);
    
    // Mapeamento melhorado seguindo a documentação da API
    const tribunalInfo = dataJudProcess.tribunal || dataJudProcess.orgaoJulgador || {};
    const orgaoJulgadorInfo = dataJudProcess.orgaoJulgador || dataJudProcess.tribunal || {};
    
    return {
      numero: dataJudProcess.numeroSequencial || dataJudProcess.numeroProcesso || '',
      classe: dataJudProcess.classe?.nome || dataJudProcess.dscClasse || 'Não informado',
      assunto: dataJudProcess.assuntos?.[0]?.nome || dataJudProcess.dscAssunto || 'Não informado',
      tribunal: tribunalInfo.nome || dataJudProcess.tribunal || 'Não informado',
      orgaoJulgador: orgaoJulgadorInfo.nome || orgaoJulgadorInfo.nomeOrgao || dataJudProcess.origem || 'Não informado',
      dataAjuizamento: dataJudProcess.dataAjuizamento || '',
      situacao: dataJudProcess.dadosBasicos?.situacao || dataJudProcess.situacao || 'Não informado',
      movimentacoes: dataJudProcess.movimentos?.map((mov: any) => ({
        data: mov.dataHora?.split('T')[0] || '',
        descricao: mov.nome || '',
        complemento: mov.complemento || mov.complementoTabelado?.descricao || mov.complementosTabelados?.[0]?.descricao || ''
      })) || [],
      // Mapeamento correto do valor da causa
      valorCausa: dataJudProcess.valorCausa || dataJudProcess.valorDaCausa || '',
      segredoJustica: dataJudProcess.segredoJustica || false,
      justicaGratuita: dataJudProcess.justicaGratuita || false,
      prioridade: dataJudProcess.prioridade || '',
      natureza: dataJudProcess.natureza || '',
      grau: dataJudProcess.grau || '',
      sistema: dataJudProcess.sistema?.nome || '',
      formato: dataJudProcess.formato?.nome || '',
      dataHoraUltimaAtualizacao: dataJudProcess.dataHoraUltimaAtualizacao || '',
      nivelSigilo: dataJudProcess.nivelSigilo || 0,
      intervencaoMP: dataJudProcess.intervencaoMP || false,
      tamanhoProcesso: dataJudProcess.tamanhoProcesso || '',
      dscClasse: dataJudProcess.dscClasse || dataJudProcess.classe?.nome || '',
      dscAssunto: dataJudProcess.dscAssunto || dataJudProcess.assuntos?.[0]?.nome || '',
      magistrado: dataJudProcess.magistrado ? {
        nome: dataJudProcess.magistrado.nome || 'Não informado',
        codigo: dataJudProcess.magistrado.codigo || 0
      } : undefined,
      serventia: dataJudProcess.serventia ? {
        codigo: dataJudProcess.serventia.codigo,
        nome: dataJudProcess.serventia.nome || 'Não informado'
      } : undefined,
      procurador: dataJudProcess.procurador || [],
      partes: dataJudProcess.partes || [],
      localProcessamento: dataJudProcess.localProcessamento || '',
      competencia: dataJudProcess.competencia || dataJudProcess.dadosBasicos?.competencia || '',
      dataDistribuicao: dataJudProcess.dataDistribuicao || '',
      dataEncerramento: dataJudProcess.dataEncerramento || '',
      tipoProcesso: dataJudProcess.tipoProcesso || '',
      instancia: dataJudProcess.instancia || (dataJudProcess.grau === 'G1' ? 1 : dataJudProcess.grau === 'G2' ? 2 : dataJudProcess.grau === 'G3' ? 3 : 0),
      origem: dataJudProcess.origem || ''
    };
  };

  const handleSingleConsultation = async (processNumber: string, dataJudService: DataJudService) => {
    setLoading(true);
    setConsultationStats(undefined);
    
    try {
      console.log('Consultando processo:', processNumber);
      
      const dataJudResult = await dataJudService.consultarProcesso(processNumber);
      const processData = convertDataJudToProcessData(dataJudResult);
      
      setResults([processData]);
      setConsultationStats({
        total: 1,
        found: 1,
        errors: []
      });
      
      toast({
        title: "Consulta realizada",
        description: "Processo consultado com sucesso!"
      });
    } catch (error) {
      console.error('Erro na consulta:', error);
      setResults([]);
      setConsultationStats({
        total: 1,
        found: 0,
        errors: [`${processNumber}: ${error instanceof Error ? error.message : 'Erro desconhecido'}`]
      });
      
      toast({
        title: "Erro na consulta",
        description: error instanceof Error ? error.message : "Erro desconhecido ao consultar processo",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleBatchConsultation = async (processes: string[], dataJudService: DataJudService) => {
    setLoading(true);
    setConsultationStats(undefined);
    
    try {
      console.log('Consultando processos em lote:', processes);
      
      const consultationErrors: string[] = [];
      const originalConsoleError = console.error;
      
      console.error = (...args) => {
        const message = args.join(' ');
        if (message.includes('✗ Erro ao consultar processo')) {
          const errorMatch = message.match(/✗ Erro ao consultar processo (.+?):/);
          if (errorMatch) {
            const processNumber = errorMatch[1];
            const errorDescription = message.substring(message.indexOf(':') + 1).trim();
            consultationErrors.push(`${processNumber}: ${errorDescription}`);
          }
        }
        originalConsoleError.apply(console, args);
      };
      
      const dataJudResults = await dataJudService.consultarProcessosLote(processes);
      const processDataResults = dataJudResults.map(convertDataJudToProcessData);
      
      console.error = originalConsoleError;
      
      setResults(processDataResults);
      setConsultationStats({
        total: processes.length,
        found: processDataResults.length,
        errors: consultationErrors
      });
      
      if (processDataResults.length === processes.length) {
        toast({
          title: "Consulta em lote concluída",
          description: `${processDataResults.length} processo(s) consultado(s) com sucesso`
        });
      } else {
        toast({
          title: "Consulta parcialmente concluída",
          description: `${processDataResults.length} de ${processes.length} processo(s) encontrado(s)`,
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Erro na consulta em lote:', error);
      setConsultationStats({
        total: processes.length,
        found: 0,
        errors: [`Erro geral: ${error instanceof Error ? error.message : 'Erro desconhecido'}`]
      });
      
      toast({
        title: "Erro na consulta em lote",
        description: "Erro ao consultar processos. Verifique os logs para mais detalhes.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAdvancedSearch = async (searchType: string, params: any, dataJudService: DataJudService) => {
    setLoading(true);
    setConsultationStats(undefined);
    
    try {
      console.log('Realizando busca avançada:', searchType, params);
      
      let dataJudResults: any[] = [];
      let searchDescription = '';

      switch (searchType) {
        case 'advanced':
          dataJudResults = await dataJudService.consultarProcessosAvancado(params);
          searchDescription = 'Busca com múltiplos filtros';
          break;
        case 'movement':
          dataJudResults = await dataJudService.consultarPorMovimentacao(params);
          searchDescription = `Busca por movimentação: ${params}`;
          break;
        case 'class':
          dataJudResults = await dataJudService.consultarPorClasse(params);
          searchDescription = `Busca por classe: ${params}`;
          break;
        case 'subject':
          dataJudResults = await dataJudService.consultarPorAssunto(params);
          searchDescription = `Busca por assunto: ${params}`;
          break;
        case 'court':
          dataJudResults = await dataJudService.consultarPorTribunal(params);
          searchDescription = `Busca por tribunal: ${params}`;
          break;
        case 'dateRange':
          dataJudResults = await dataJudService.consultarPorPeriodo(params.startDate, params.endDate);
          searchDescription = `Busca por período: ${params.startDate} a ${params.endDate}`;
          break;
        default:
          throw new Error('Tipo de busca não reconhecido');
      }

      const processDataResults = dataJudResults.map(convertDataJudToProcessData);
      
      setResults(processDataResults);
      setConsultationStats({
        total: dataJudResults.length,
        found: processDataResults.length,
        errors: []
      });
      
      toast({
        title: "Busca concluída",
        description: `${searchDescription}: ${processDataResults.length} processo(s) encontrado(s)`
      });
    } catch (error) {
      console.error('Erro na busca avançada:', error);
      setResults([]);
      setConsultationStats({
        total: 0,
        found: 0,
        errors: [`Erro na busca: ${error instanceof Error ? error.message : 'Erro desconhecido'}`]
      });
      
      toast({
        title: "Erro na busca",
        description: error instanceof Error ? error.message : "Erro desconhecido ao realizar busca",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return {
    results,
    loading,
    consultationStats,
    handleSingleConsultation,
    handleBatchConsultation,
    handleAdvancedSearch
  };
};
