
import { Badge } from '@/components/ui/badge';
import { Hash } from 'lucide-react';

interface Movement {
  data: string;
  descricao: string;
  complemento?: string;
}

interface ProcessMovementsProps {
  movimentacoes: Movement[];
}

export const ProcessMovements = ({ movimentacoes }: ProcessMovementsProps) => {
  return (
    <div>
      <h4 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
        <Hash className="h-4 w-4" />
        Histórico de Movimentações ({movimentacoes.length})
      </h4>
      <div className="space-y-3 max-h-60 overflow-y-auto">
        {movimentacoes.map((movimento, movIndex) => (
          <div key={movIndex} className="border-l-2 border-blue-200 pl-4 py-2 hover:bg-gray-50 rounded-r">
            <div className="flex items-center gap-2 mb-1">
              <Badge variant="secondary" className="text-xs">
                {movimento.data ? new Date(movimento.data).toLocaleDateString('pt-BR') : 'Data não informada'}
              </Badge>
              <span className="font-medium text-sm">{movimento.descricao}</span>
            </div>
            {movimento.complemento && (
              <p className="text-sm text-gray-600 mt-1 pl-2 border-l-2 border-gray-200">
                {movimento.complemento}
              </p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
