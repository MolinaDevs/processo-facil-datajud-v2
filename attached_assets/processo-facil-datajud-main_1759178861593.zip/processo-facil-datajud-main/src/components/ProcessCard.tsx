
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { ProcessMovements } from './ProcessMovements';
import { ProcessHeader } from './ProcessCard/ProcessHeader';
import { ProcessIdentification } from './ProcessCard/ProcessIdentification';
import { ProcessJurisdiction } from './ProcessCard/ProcessJurisdiction';
import { ProcessDatesAndValues } from './ProcessCard/ProcessDatesAndValues';
import { ProcessMagistrateAndCourt } from './ProcessCard/ProcessMagistrateAndCourt';
import { ProcessCharacteristics } from './ProcessCard/ProcessCharacteristics';
import { ProcessParties } from './ProcessCard/ProcessParties';
import { ProcessAttorneys } from './ProcessCard/ProcessAttorneys';
import { ProcessTechnicalInfo } from './ProcessCard/ProcessTechnicalInfo';
import { ProcessData } from '@/types/process';

interface ProcessCardProps {
  process: ProcessData;
  index: number;
}

export const ProcessCard = ({ process, index }: ProcessCardProps) => {
  return (
    <Card key={index} className="overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
        <ProcessHeader process={process} />
      </CardHeader>
      
      <CardContent className="pt-6">
        {/* Informações Principais */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 mb-6">
          <ProcessIdentification process={process} />
          <ProcessJurisdiction process={process} />
          <ProcessDatesAndValues process={process} />
        </div>

        {/* Informações Complementares */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <ProcessMagistrateAndCourt process={process} />
          <ProcessCharacteristics process={process} />
        </div>

        {/* Partes do Processo */}
        <ProcessParties process={process} />

        {/* Procuradores */}
        <ProcessAttorneys process={process} />

        {/* Informações Técnicas */}
        <ProcessTechnicalInfo process={process} />

        <Separator className="my-4" />

        {/* Movimentações */}
        <ProcessMovements movimentacoes={process.movimentacoes} />
      </CardContent>
    </Card>
  );
};
