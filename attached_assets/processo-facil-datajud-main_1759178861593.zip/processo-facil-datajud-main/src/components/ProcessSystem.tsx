
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ProcessConsultation } from '@/components/ProcessConsultation';
import { BatchUpload } from '@/components/BatchUpload';
import { ProcessResults } from '@/components/ProcessResults';
import { ApiKeyInput } from '@/components/ApiKeyInput';
import { AdvancedSearch } from '@/components/AdvancedSearch';
import { FileText, Upload, Search, Filter } from 'lucide-react';
import { DataJudService } from '@/services/datajudApi';
import { toast } from '@/hooks/use-toast';
import { useProcessConsultation } from '@/hooks/useProcessConsultation';

export const ProcessSystem = () => {
  const [apiKey, setApiKey] = useState<string>('');
  const [dataJudService, setDataJudService] = useState<DataJudService | null>(null);
  
  const {
    results,
    loading,
    consultationStats,
    handleSingleConsultation,
    handleBatchConsultation,
    handleAdvancedSearch
  } = useProcessConsultation();

  const handleApiKeySubmit = (key: string) => {
    setApiKey(key);
    setDataJudService(new DataJudService(key));
    localStorage.setItem('datajud_api_key', key);
    toast({
      title: "API Key configurada",
      description: "Chave da API DataJud configurada com sucesso!"
    });
  };

  const onSingleConsultation = async (processNumber: string) => {
    if (!dataJudService) {
      toast({
        title: "API Key necessária",
        description: "Por favor, configure sua chave da API DataJud primeiro",
        variant: "destructive"
      });
      return;
    }
    await handleSingleConsultation(processNumber, dataJudService);
  };

  const onBatchConsultation = async (processes: string[]) => {
    if (!dataJudService) {
      toast({
        title: "API Key necessária",
        description: "Por favor, configure sua chave da API DataJud primeiro",
        variant: "destructive"
      });
      return;
    }
    await handleBatchConsultation(processes, dataJudService);
  };

  const onAdvancedSearch = async (searchType: string, params: any) => {
    if (!dataJudService) {
      toast({
        title: "API Key necessária",
        description: "Por favor, configure sua chave da API DataJud primeiro",
        variant: "destructive"
      });
      return;
    }
    await handleAdvancedSearch(searchType, params, dataJudService);
  };

  // Verificar se existe API key salva no localStorage
  const savedApiKey = localStorage.getItem('datajud_api_key');
  if (savedApiKey && !dataJudService) {
    setApiKey(savedApiKey);
    setDataJudService(new DataJudService(savedApiKey));
  }

  return (
    <>
      {/* API Key Configuration */}
      {!dataJudService && (
        <Card className="mb-8 border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="text-orange-800">Configuração Necessária</CardTitle>
            <CardDescription className="text-orange-700">
              Para usar este sistema, você precisa configurar sua chave da API DataJud
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ApiKeyInput onSubmit={handleApiKeySubmit} />
          </CardContent>
        </Card>
      )}

      {/* Main Content */}
      <div className="max-w-6xl mx-auto">
        <Tabs defaultValue="individual" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="individual" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Consulta Individual
            </TabsTrigger>
            <TabsTrigger value="advanced" className="flex items-center gap-2">
              <Filter className="h-4 w-4" />
              Busca Avançada
            </TabsTrigger>
            <TabsTrigger value="batch" className="flex items-center gap-2">
              <Upload className="h-4 w-4" />
              Upload Planilha
            </TabsTrigger>
            <TabsTrigger value="results" className="flex items-center gap-2">
              <Search className="h-4 w-4" />
              Resultados
            </TabsTrigger>
          </TabsList>

          <TabsContent value="individual" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Consulta Individual de Processo</CardTitle>
                <CardDescription>
                  Digite o número do processo para consultar todas as informações disponíveis
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ProcessConsultation 
                  onConsult={onSingleConsultation}
                  loading={loading}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="advanced" className="space-y-6">
            <AdvancedSearch 
              onSearch={onAdvancedSearch}
              loading={loading}
            />
          </TabsContent>

          <TabsContent value="batch" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Upload de Planilha Excel</CardTitle>
                <CardDescription>
                  Faça upload de uma planilha Excel com múltiplos números de processo para consulta em lote
                </CardDescription>
              </CardHeader>
              <CardContent>
                <BatchUpload 
                  onConsult={onBatchConsultation}
                  loading={loading}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="results" className="space-y-6">
            <ProcessResults 
              results={results}
              loading={loading}
              consultationStats={consultationStats}
            />
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};
