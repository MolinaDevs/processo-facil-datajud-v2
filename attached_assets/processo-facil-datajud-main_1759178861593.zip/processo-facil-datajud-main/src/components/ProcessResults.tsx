
import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText } from 'lucide-react';
import { ProcessStatsCard } from './ProcessStatsCard';
import { ProcessSearchControls } from './ProcessSearchControls';
import { ProcessCard } from './ProcessCard';
import { ProcessData, ConsultationStats } from '@/types/process';

interface ProcessResultsProps {
  results: ProcessData[];
  loading: boolean;
  consultationStats?: ConsultationStats;
}

export const ProcessResults = ({ results, loading, consultationStats }: ProcessResultsProps) => {
  const [filteredResults, setFilteredResults] = useState<ProcessData[]>(results);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    setFilteredResults(results);
  }, [results]);

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-500">Consultando processos...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (results.length === 0 && !consultationStats) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <div className="text-center">
            <FileText className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-700 mb-2">
              Nenhum processo consultado
            </h3>
            <p className="text-gray-500">
              Use as abas acima para consultar processos individuais ou fazer upload de planilhas
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {consultationStats && (
        <ProcessStatsCard consultationStats={consultationStats} />
      )}

      {results.length > 0 && (
        <ProcessSearchControls 
          results={results} 
          onFilteredResults={setFilteredResults} 
        />
      )}

      {results.length > 0 && (
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-900">
            Resultados ({filteredResults.length} processo{filteredResults.length !== 1 ? 's' : ''})
          </h2>
          {searchTerm && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setSearchTerm('');
                setFilteredResults(results);
              }}
            >
              Limpar filtro
            </Button>
          )}
        </div>
      )}

      {results.length > 0 && (
        <div className="space-y-4">
          {filteredResults.map((process, index) => (
            <ProcessCard key={index} process={process} index={index} />
          ))}
        </div>
      )}
    </div>
  );
};
