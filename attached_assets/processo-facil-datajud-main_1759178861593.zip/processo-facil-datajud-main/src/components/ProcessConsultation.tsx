
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Search, Loader2 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface ProcessConsultationProps {
  onConsult: (processNumber: string) => Promise<void>;
  loading: boolean;
}

export const ProcessConsultation = ({ onConsult, loading }: ProcessConsultationProps) => {
  const [processNumber, setProcessNumber] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!processNumber.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, digite o número do processo",
        variant: "destructive"
      });
      return;
    }

    // Validação básica do formato do número do processo
    const processRegex = /^\d{7}-\d{2}\.\d{4}\.\d{1}\.\d{2}\.\d{4}$/;
    if (!processRegex.test(processNumber)) {
      toast({
        title: "Formato inválido",
        description: "O número do processo deve seguir o formato: NNNNNNN-DD.AAAA.J.TR.OOOO",
        variant: "destructive"
      });
      return;
    }

    try {
      await onConsult(processNumber);
      toast({
        title: "Consulta realizada",
        description: "Processo consultado com sucesso!"
      });
    } catch (error) {
      toast({
        title: "Erro na consulta",
        description: "Não foi possível consultar o processo. Tente novamente.",
        variant: "destructive"
      });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="processNumber">Número do Processo</Label>
        <Input
          id="processNumber"
          type="text"
          placeholder="0000000-00.0000.0.00.0000"
          value={processNumber}
          onChange={(e) => setProcessNumber(e.target.value)}
          className="font-mono"
        />
        <p className="text-sm text-gray-500">
          Formato: NNNNNNN-DD.AAAA.J.TR.OOOO
        </p>
      </div>
      
      <Button 
        type="submit" 
        disabled={loading}
        className="w-full bg-blue-600 hover:bg-blue-700"
      >
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Consultando...
          </>
        ) : (
          <>
            <Search className="mr-2 h-4 w-4" />
            Consultar Processo
          </>
        )}
      </Button>
    </form>
  );
};
