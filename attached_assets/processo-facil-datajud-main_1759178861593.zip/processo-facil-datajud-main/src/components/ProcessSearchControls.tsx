
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Search, 
  Filter,
  FileSpreadsheet,
  FileText
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import * as XLSX from 'xlsx';

interface ProcessData {
  numero: string;
  classe: string;
  assunto: string;
  tribunal: string;
  orgaoJulgador: string;
  dataAjuizamento: string;
  situacao: string;
  movimentacoes: Array<{
    data: string;
    descricao: string;
    complemento?: string;
  }>;
}

interface ProcessSearchControlsProps {
  results: ProcessData[];
  onFilteredResults: (filtered: ProcessData[]) => void;
}

export const ProcessSearchControls = ({ results, onFilteredResults }: ProcessSearchControlsProps) => {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = () => {
    if (!searchTerm.trim()) {
      onFilteredResults(results);
      return;
    }

    const filtered = results.map(process => {
      const matchingMovimentos = process.movimentacoes.filter(mov => 
        mov.descricao.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (mov.complemento && mov.complemento.toLowerCase().includes(searchTerm.toLowerCase()))
      );

      const hasKeyword = 
        process.classe.toLowerCase().includes(searchTerm.toLowerCase()) ||
        process.assunto.toLowerCase().includes(searchTerm.toLowerCase()) ||
        matchingMovimentos.length > 0;

      if (hasKeyword) {
        return {
          ...process,
          movimentacoes: matchingMovimentos.length > 0 ? matchingMovimentos : process.movimentacoes
        };
      }
      return null;
    }).filter(Boolean) as ProcessData[];

    onFilteredResults(filtered);
    
    if (filtered.length === 0 && searchTerm.trim()) {
      toast({
        title: "Nenhum resultado encontrado",
        description: `Não foram encontrados processos com a palavra-chave "${searchTerm}"`,
        variant: "destructive"
      });
    } else {
      toast({
        title: "Busca realizada",
        description: `${filtered.length} processo(s) encontrado(s) com a palavra-chave "${searchTerm}"`
      });
    }
  };

  const exportToExcel = () => {
    console.log('Exportando para Excel:', results);
    
    try {
      // Preparar dados para o Excel
      const excelData = [];
      
      // Cabeçalhos
      excelData.push([
        'Número do Processo',
        'Classe',
        'Assunto',
        'Tribunal',
        'Órgão Julgador',
        'Data Ajuizamento',
        'Situação',
        'Movimentações'
      ]);
      
      // Dados dos processos
      results.forEach(process => {
        // Concatenar movimentações em uma única string
        const movimentacoesText = process.movimentacoes
          .map(mov => `${mov.data} - ${mov.descricao}${mov.complemento ? ` (${mov.complemento})` : ''}`)
          .join('\n');
        
        excelData.push([
          process.numero,
          process.classe,
          process.assunto,
          process.tribunal,
          process.orgaoJulgador,
          process.dataAjuizamento,
          process.situacao,
          movimentacoesText
        ]);
      });
      
      // Criar planilha
      const worksheet = XLSX.utils.aoa_to_sheet(excelData);
      
      // Ajustar largura das colunas
      const colWidths = [
        { wch: 25 }, // Número do Processo
        { wch: 20 }, // Classe
        { wch: 30 }, // Assunto
        { wch: 15 }, // Tribunal
        { wch: 25 }, // Órgão Julgador
        { wch: 15 }, // Data Ajuizamento
        { wch: 15 }, // Situação
        { wch: 50 }  // Movimentações
      ];
      worksheet['!cols'] = colWidths;
      
      // Criar workbook
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Processos');
      
      // Gerar e baixar arquivo
      const fileName = `processos_${new Date().toISOString().split('T')[0]}.xlsx`;
      XLSX.writeFile(workbook, fileName);
      
      toast({
        title: "Exportação concluída",
        description: "Os dados foram exportados para Excel com sucesso"
      });
    } catch (error) {
      console.error('Erro ao exportar para Excel:', error);
      toast({
        title: "Erro na exportação",
        description: "Não foi possível exportar os dados para Excel",
        variant: "destructive"
      });
    }
  };

  const exportToTxt = () => {
    let txtContent = 'RELATÓRIO DE PROCESSOS\n';
    txtContent += '========================\n\n';
    
    results.forEach((process, index) => {
      txtContent += `${index + 1}. PROCESSO: ${process.numero}\n`;
      txtContent += `   Classe: ${process.classe}\n`;
      txtContent += `   Assunto: ${process.assunto}\n`;
      txtContent += `   Tribunal: ${process.tribunal}\n`;
      txtContent += `   Órgão Julgador: ${process.orgaoJulgador}\n`;
      txtContent += `   Data Ajuizamento: ${process.dataAjuizamento}\n`;
      txtContent += `   Situação: ${process.situacao}\n`;
      txtContent += `   Movimentações:\n`;
      
      process.movimentacoes.forEach((mov, movIndex) => {
        txtContent += `   ${movIndex + 1}. ${mov.data} - ${mov.descricao}\n`;
        if (mov.complemento) {
          txtContent += `      ${mov.complemento}\n`;
        }
      });
      txtContent += '\n';
    });

    const dataBlob = new Blob([txtContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `processos_${new Date().toISOString().split('T')[0]}.txt`;
    link.click();
    
    toast({
      title: "Exportação concluída",
      description: "O relatório foi exportado em formato TXT"
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="h-5 w-5" />
          Buscar por Palavra-chave
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Digite uma palavra-chave (ex: citação, sentença, recurso...)"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
          />
          <Button onClick={handleSearch} variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Filtrar
          </Button>
        </div>
        
        <div className="flex gap-2">
          <Button onClick={exportToExcel} variant="outline" size="sm">
            <FileSpreadsheet className="h-4 w-4 mr-2" />
            Exportar Excel
          </Button>
          <Button onClick={exportToTxt} variant="outline" size="sm">
            <FileText className="h-4 w-4 mr-2" />
            Exportar TXT
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
