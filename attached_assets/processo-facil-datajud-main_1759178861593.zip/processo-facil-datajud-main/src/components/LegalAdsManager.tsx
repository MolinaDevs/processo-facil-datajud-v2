
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, Target } from 'lucide-react';
import { useGoogleAds } from '@/hooks/useGoogleAds';

interface LegalAd {
  id: string;
  title: string;
  description: string;
  url: string;
  imageUrl?: string;
  category: 'software' | 'curso' | 'consultoria' | 'servico';
  price?: string;
  isSponsored: boolean;
}

const MOCK_ADS: LegalAd[] = [
  {
    id: '1',
    title: 'Software Jurídico Completo - LexSoft Pro',
    description: 'Gerencie processos, clientes e prazos em uma única plataforma. Teste grátis por 30 dias. Mais de 10.000 advogados confiam na nossa solução.',
    url: 'https://exemplo.com/software-juridico',
    category: 'software',
    price: 'A partir de R$ 89/mês',
    isSponsored: true
  },
  {
    id: '2',
    title: 'Curso Online: Direito Processual Civil 2024',
    description: 'Aprenda com especialistas e atualize seus conhecimentos com as últimas mudanças. Certificado incluso e acesso vitalício.',
    url: 'https://exemplo.com/curso-direito',
    category: 'curso',
    price: 'R$ 297',
    isSponsored: true
  },
  {
    id: '3',
    title: 'Consultoria em Compliance Jurídico',
    description: 'Assessoria especializada para adequação às normas regulamentares. Equipe de especialistas em LGPD e Marco Civil.',
    url: 'https://exemplo.com/consultoria',
    category: 'consultoria',
    price: 'Consulte nossos valores',
    isSponsored: false
  },
  {
    id: '4',
    title: 'Petições Automatizadas com IA - JurisBot',
    description: 'Sistema de geração automática de petições com Inteligência Artificial. Economize até 80% do seu tempo.',
    url: 'https://exemplo.com/peticoes-ia',
    category: 'servico',
    price: 'R$ 49/mês',
    isSponsored: true
  },
  {
    id: '5',
    title: 'MBA em Direito Digital - UniJuris',
    description: 'Especialização completa em Direito Digital, Criptomoedas e NFTs. Reconhecido pelo MEC.',
    url: 'https://exemplo.com/mba-direito-digital',
    category: 'curso',
    price: 'R$ 1.299 (12x)',
    isSponsored: true
  },
  {
    id: '6',
    title: 'Serviços de Perícia Judicial',
    description: 'Equipe especializada em perícias contábeis, trabalhistas e cíveis. Atendimento em todo território nacional.',
    url: 'https://exemplo.com/pericia-judicial',
    category: 'servico',
    price: 'A partir de R$ 300',
    isSponsored: false
  }
];

const getCategoryLabel = (category: string) => {
  const labels = {
    software: 'Software',
    curso: 'Curso',
    consultoria: 'Consultoria',
    servico: 'Serviço'
  };
  return labels[category as keyof typeof labels] || category;
};

const getCategoryColor = (category: string) => {
  const colors = {
    software: 'bg-blue-100 text-blue-800',
    curso: 'bg-green-100 text-green-800',
    consultoria: 'bg-purple-100 text-purple-800',
    servico: 'bg-orange-100 text-orange-800'
  };
  return colors[category as keyof typeof colors] || 'bg-gray-100 text-gray-800';
};

export const LegalAdsManager = () => {
  const [ads, setAds] = useState<LegalAd[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewedAds, setViewedAds] = useState<Set<string>>(new Set());
  const { trackEvent, trackConversion } = useGoogleAds();

  useEffect(() => {
    // Simular carregamento dos anúncios
    const loadAds = async () => {
      console.log('Carregando anúncios...');
      setLoading(true);
      
      // Simular delay de carregamento
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setAds(MOCK_ADS);
      setLoading(false);
      console.log('Anúncios carregados:', MOCK_ADS.length);
    };

    loadAds();
  }, []);

  useEffect(() => {
    // Rastrear impressão dos anúncios
    if (ads.length > 0) {
      ads.forEach(ad => {
        if (ad.isSponsored && !viewedAds.has(ad.id)) {
          trackEvent('ad_impression', {
            ad_id: ad.id,
            ad_category: ad.category,
            ad_title: ad.title
          });
          setViewedAds(prev => new Set([...prev, ad.id]));
        }
      });
    }
  }, [ads, viewedAds, trackEvent]);

  const handleAdClick = (ad: LegalAd) => {
    console.log('Clique no anúncio:', ad.title);
    
    // Rastrear clique no anúncio
    trackEvent('ad_click', {
      ad_id: ad.id,
      ad_category: ad.category,
      ad_title: ad.title,
      ad_url: ad.url
    });

    // Se for um anúncio patrocinado, rastrear como conversão
    if (ad.isSponsored) {
      trackConversion(1, 'BRL');
    }

    // Abrir link em nova aba
    window.open(ad.url, '_blank', 'noopener,noreferrer');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando anúncios...</p>
        </div>
      </div>
    );
  }

  if (ads.length === 0) {
    return (
      <div className="text-center py-8">
        <Target className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">
          Nenhum anúncio disponível
        </h3>
        <p className="text-gray-600">
          Não há anúncios para exibir no momento.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          Anúncios Jurídicos
        </h2>
        <p className="text-gray-600">
          Soluções e serviços especializados para profissionais do direito
        </p>
        <p className="text-sm text-blue-600 mt-2">
          {ads.length} anúncios disponíveis
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {ads.map((ad) => (
          <Card key={ad.id} className="hover:shadow-lg transition-all duration-200 cursor-pointer border-2 hover:border-blue-200">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg flex items-center gap-2 mb-2">
                    {ad.title}
                    {ad.isSponsored && (
                      <Badge variant="secondary" className="text-xs bg-yellow-100 text-yellow-800">
                        Patrocinado
                      </Badge>
                    )}
                  </CardTitle>
                  <Badge className={`${getCategoryColor(ad.category)}`}>
                    {getCategoryLabel(ad.category)}
                  </Badge>
                </div>
                <Target className="h-4 w-4 text-gray-400 flex-shrink-0" />
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600 text-sm leading-relaxed">{ad.description}</p>
              
              <div className="flex items-center justify-between pt-2">
                {ad.price && (
                  <span className="font-semibold text-blue-600 text-sm">{ad.price}</span>
                )}
                <Button
                  size="sm"
                  onClick={() => handleAdClick(ad)}
                  className="ml-auto bg-blue-600 hover:bg-blue-700"
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Ver mais
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="text-center text-sm text-gray-500 mt-8 p-4 bg-gray-50 rounded-lg">
        <p className="mb-2">
          <strong>Quer anunciar aqui?</strong>
        </p>
        <p>
          Entre em contato conosco para saber mais sobre nossos planos de publicidade.
          Alcance milhares de profissionais do direito!
        </p>
        <Button variant="outline" size="sm" className="mt-3">
          Anunciar Aqui
        </Button>
      </div>
    </div>
  );
};
