
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  AlertTriangle,
  CheckCircle,
  XCircle,
  FileText
} from 'lucide-react';

interface ProcessStatsCardProps {
  consultationStats: {
    total: number;
    found: number;
    errors: string[];
  };
}

export const ProcessStatsCard = ({ consultationStats }: ProcessStatsCardProps) => {
  return (
    <Card className="border-blue-200 bg-blue-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-blue-900">
          <AlertTriangle className="h-5 w-5" />
          Relatório da Consulta
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-gray-600" />
            <span className="font-medium">Total consultados:</span>
            <Badge variant="outline">{consultationStats.total}</Badge>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <span className="font-medium">Encontrados:</span>
            <Badge variant="default" className="bg-green-600">{consultationStats.found}</Badge>
          </div>
          <div className="flex items-center gap-2">
            <XCircle className="h-5 w-5 text-red-600" />
            <span className="font-medium">Não encontrados:</span>
            <Badge variant="destructive">{consultationStats.total - consultationStats.found}</Badge>
          </div>
        </div>
        
        {consultationStats.errors.length > 0 && (
          <div>
            <h4 className="font-semibold text-red-800 mb-2">Processos não encontrados:</h4>
            <div className="max-h-32 overflow-y-auto space-y-1">
              {consultationStats.errors.map((erro, index) => (
                <Alert key={index} className="py-2">
                  <XCircle className="h-4 w-4" />
                  <AlertDescription className="text-sm">{erro}</AlertDescription>
                </Alert>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
