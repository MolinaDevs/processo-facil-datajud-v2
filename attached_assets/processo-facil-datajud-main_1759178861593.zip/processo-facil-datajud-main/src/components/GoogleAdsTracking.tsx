
import { useEffect } from 'react';

// Extensão da interface Window para incluir dataLayer e gtag
declare global {
  interface Window {
    dataLayer: any[];
    gtag: (...args: any[]) => void;
    trackGoogleAdsConversion: (value?: number, currency?: string) => void;
  }
}

interface GoogleAdsTrackingProps {
  conversionId: string;
  conversionLabel?: string;
}

export const GoogleAdsTracking = ({ conversionId, conversionLabel }: GoogleAdsTrackingProps) => {
  useEffect(() => {
    // Carregar o script do Google Ads
    const script = document.createElement('script');
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${conversionId}`;
    document.head.appendChild(script);

    // Configurar o gtag
    window.dataLayer = window.dataLayer || [];
    function gtag(...args: any[]) {
      window.dataLayer.push(args);
    }
    window.gtag = gtag;

    gtag('js', new Date());
    gtag('config', conversionId);

    return () => {
      // Cleanup se necessário
      if (document.head.contains(script)) {
        document.head.removeChild(script);
      }
    };
  }, [conversionId]);

  // Função para rastrear conversões
  const trackConversion = (value?: number, currency = 'BRL') => {
    if (conversionLabel && window.gtag) {
      window.gtag('event', 'conversion', {
        send_to: `${conversionId}/${conversionLabel}`,
        value: value,
        currency: currency,
      });
    }
  };

  // Expor a função globalmente para uso em outros componentes
  useEffect(() => {
    window.trackGoogleAdsConversion = trackConversion;
  }, [trackConversion]);

  return null;
};
