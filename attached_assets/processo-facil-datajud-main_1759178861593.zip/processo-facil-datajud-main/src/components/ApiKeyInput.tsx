import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Key, Eye, EyeOff, ExternalLink, AlertTriangle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface ApiKeyInputProps {
  onSubmit: (apiKey: string) => void;
}

export const ApiKeyInput = ({ onSubmit }: ApiKeyInputProps) => {
  const [apiKey, setApiKey] = useState('');
  const [showKey, setShowKey] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (apiKey.trim()) {
      onSubmit(apiKey.trim());
    }
  };

  return (
    <div className="space-y-4">
      <Alert className="border-amber-200 bg-amber-50">
        <AlertTriangle className="h-4 w-4 text-amber-600" />
        <AlertDescription className="text-amber-800">
          <strong>Importante:</strong> Esta aplicação utiliza um proxy para contornar restrições de CORS. 
          Certifique-se de que o servidor de desenvolvimento está rodando na porta correta.
        </AlertDescription>
      </Alert>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="apiKey">Chave da API DataJud</Label>
          <div className="relative">
            <Input
              id="apiKey"
              type={showKey ? "text" : "password"}
              placeholder="Digite sua chave da API DataJud"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              className="pr-10"
            />
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
              onClick={() => setShowKey(!showKey)}
            >
              {showKey ? (
                <EyeOff className="h-4 w-4" />
              ) : (
                <Eye className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>
        
        <Button 
          type="submit" 
          disabled={!apiKey.trim()}
          className="w-full bg-blue-600 hover:bg-blue-700"
        >
          <Key className="mr-2 h-4 w-4" />
          Configurar API Key
        </Button>
      </form>

      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <h4 className="font-semibold text-blue-900 mb-2">Como obter sua API Key:</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Acesse o portal de APIs do CNJ</li>
            <li>• Registre-se ou faça login</li>
            <li>• Solicite acesso à API DataJud</li>
            <li>• Copie sua chave de API</li>
          </ul>
          <Button
            variant="outline"
            size="sm"
            className="mt-3 text-blue-700 border-blue-300"
            onClick={() => window.open('https://datajud-wiki.cnj.jus.br/', '_blank')}
          >
            <ExternalLink className="mr-2 h-3 w-3" />
            Documentação da API
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};
