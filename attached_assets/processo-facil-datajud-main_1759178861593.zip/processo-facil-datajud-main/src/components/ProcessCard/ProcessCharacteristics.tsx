
import { AlertCircle, Shield } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { ProcessData } from '@/types/process';

interface ProcessCharacteristicsProps {
  process: ProcessData;
}

export const ProcessCharacteristics = ({ process }: ProcessCharacteristicsProps) => {
  return (
    <div className="space-y-4">
      <h4 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
        <AlertCircle className="h-4 w-4" />
        Características
      </h4>
      <div className="space-y-2">
        <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
          <span className="text-sm text-gray-600">Movimentações</span>
          <Badge variant="outline">{process.movimentacoes.length}</Badge>
        </div>
        
        {process.prioridade && (
          <div className="flex items-center justify-between p-2 bg-yellow-50 rounded">
            <span className="text-sm text-gray-600">Prioridade</span>
            <Badge variant="default" className="bg-yellow-600 text-xs">{process.prioridade}</Badge>
          </div>
        )}
        
        {process.segredoJustica && (
          <div className="flex items-center justify-between p-2 bg-red-50 rounded">
            <span className="text-sm text-gray-600">Segredo de Justiça</span>
            <Badge variant="destructive" className="text-xs">
              <Shield className="h-3 w-3 mr-1" />
              Sim
            </Badge>
          </div>
        )}
        
        {process.justicaGratuita && (
          <div className="flex items-center justify-between p-2 bg-green-50 rounded">
            <span className="text-sm text-gray-600">Justiça Gratuita</span>
            <Badge variant="default" className="bg-green-600 text-xs">Sim</Badge>
          </div>
        )}
        
        {process.intervencaoMP && (
          <div className="flex items-center justify-between p-2 bg-purple-50 rounded">
            <span className="text-sm text-gray-600">Intervenção MP</span>
            <Badge variant="default" className="bg-purple-600 text-xs">Sim</Badge>
          </div>
        )}
        
        {process.nivelSigilo && process.nivelSigilo > 0 && (
          <div className="flex items-center justify-between p-2 bg-orange-50 rounded">
            <span className="text-sm text-gray-600">Nível de Sigilo</span>
            <Badge variant="outline" className="text-xs">{process.nivelSigilo}</Badge>
          </div>
        )}
        
        {process.tamanhoProcesso && (
          <div className="flex items-center justify-between p-2 bg-blue-50 rounded">
            <span className="text-sm text-gray-600">Tamanho</span>
            <Badge variant="outline" className="text-xs">{process.tamanhoProcesso}</Badge>
          </div>
        )}
      </div>
    </div>
  );
};
