
import { Gavel } from 'lucide-react';
import { ProcessData } from '@/types/process';

interface ProcessMagistrateAndCourtProps {
  process: ProcessData;
}

export const ProcessMagistrateAndCourt = ({ process }: ProcessMagistrateAndCourtProps) => {
  if (!process.magistrado && !process.serventia) {
    return null;
  }

  return (
    <div className="space-y-4">
      <h4 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
        <Gavel className="h-4 w-4" />
        Magistrado e Serventia
      </h4>
      <div className="space-y-2 text-sm">
        {process.magistrado && (
          <div className="flex">
            <span className="font-medium w-24 text-gray-600">Magistrado:</span>
            <span>{process.magistrado.nome}</span>
          </div>
        )}
        {process.serventia && (
          <div className="flex">
            <span className="font-medium w-24 text-gray-600">Serventia:</span>
            <span>{process.serventia.nome}</span>
          </div>
        )}
      </div>
    </div>
  );
};
