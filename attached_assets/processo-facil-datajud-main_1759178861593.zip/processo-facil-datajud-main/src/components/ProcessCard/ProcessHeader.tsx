
import { Scale, Shield } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { CardTitle } from '@/components/ui/card';
import { ProcessData } from '@/types/process';

interface ProcessHeaderProps {
  process: ProcessData;
}

export const ProcessHeader = ({ process }: ProcessHeaderProps) => {
  return (
    <div className="flex items-center justify-between">
      <CardTitle className="flex items-center gap-2 text-blue-900">
        <Scale className="h-5 w-5" />
        Processo: {process.numero}
      </CardTitle>
      <div className="flex gap-2">
        <Badge variant="outline" className="bg-white">
          {process.situacao}
        </Badge>
        {process.segredoJustica && (
          <Badge variant="destructive" className="bg-red-600">
            <Shield className="h-3 w-3 mr-1" />
            Segredo
          </Badge>
        )}
        {process.justicaGratuita && (
          <Badge variant="default" className="bg-green-600">
            Gratuita
          </Badge>
        )}
      </div>
    </div>
  );
};
