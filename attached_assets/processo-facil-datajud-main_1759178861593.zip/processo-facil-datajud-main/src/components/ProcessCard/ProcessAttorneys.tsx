
import { Briefcase } from 'lucide-react';
import { ProcessData } from '@/types/process';

interface ProcessAttorneysProps {
  process: ProcessData;
}

export const ProcessAttorneys = ({ process }: ProcessAttorneysProps) => {
  if (!process.procurador || process.procurador.length === 0) {
    return null;
  }

  return (
    <div className="mb-6">
      <h4 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
        <Briefcase className="h-4 w-4" />
        Procuradores
      </h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {process.procurador.map((proc, index) => (
          <div key={index} className="p-3 border rounded-lg bg-gray-50">
            <div className="font-medium text-sm mb-1">{proc.nome}</div>
            <div className="text-xs text-gray-600 space-y-1">
              {proc.oab && <div>OAB: {proc.oab}</div>}
              {proc.cpf && <div>CPF: {proc.cpf}</div>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
