
import { Users } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { ProcessData } from '@/types/process';

interface ProcessPartiesProps {
  process: ProcessData;
}

export const ProcessParties = ({ process }: ProcessPartiesProps) => {
  if (!process.partes || process.partes.length === 0) {
    return null;
  }

  return (
    <div className="mb-6">
      <h4 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
        <Users className="h-4 w-4" />
        Partes do Processo
      </h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {process.partes.map((parte, index) => (
          <div key={index} className="p-3 border rounded-lg bg-gray-50">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium text-sm">{parte.nome}</span>
              <Badge variant="outline" className="text-xs">{parte.polo}</Badge>
            </div>
            <div className="text-xs text-gray-600 space-y-1">
              <div>Tipo: {parte.tipoPessoa}</div>
              {parte.cpfCnpj && <div>CPF/CNPJ: {parte.cpfCnpj}</div>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
