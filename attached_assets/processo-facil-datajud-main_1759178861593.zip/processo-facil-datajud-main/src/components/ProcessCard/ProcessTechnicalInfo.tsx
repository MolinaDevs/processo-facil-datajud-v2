
import { FileText } from 'lucide-react';
import { ProcessData } from '@/types/process';

interface ProcessTechnicalInfoProps {
  process: ProcessData;
}

export const ProcessTechnicalInfo = ({ process }: ProcessTechnicalInfoProps) => {
  if (!process.sistema && !process.formato) {
    return null;
  }

  return (
    <div className="mb-6">
      <h4 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
        <FileText className="h-4 w-4" />
        Informações Técnicas
      </h4>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
        {process.sistema && (
          <div className="flex">
            <span className="font-medium w-20 text-gray-600">Sistema:</span>
            <span>{process.sistema}</span>
          </div>
        )}
        {process.formato && (
          <div className="flex">
            <span className="font-medium w-20 text-gray-600">Formato:</span>
            <span>{process.formato}</span>
          </div>
        )}
      </div>
    </div>
  );
};
