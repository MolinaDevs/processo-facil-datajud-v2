
import { Building } from 'lucide-react';
import { ProcessData } from '@/types/process';

interface ProcessJurisdictionProps {
  process: ProcessData;
}

export const ProcessJurisdiction = ({ process }: ProcessJurisdictionProps) => {
  return (
    <div className="space-y-4">
      <h4 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
        <Building className="h-4 w-4" />
        Jurisdição
      </h4>
      <div className="space-y-2 text-sm">
        <div className="flex">
          <span className="font-medium w-24 text-gray-600">Tribunal:</span>
          <span className="font-semibold text-blue-700">{process.tribunal}</span>
        </div>
        <div className="flex">
          <span className="font-medium w-24 text-gray-600">Órgão:</span>
          <span className="font-semibold text-green-700">{process.orgaoJulgador}</span>
        </div>
        <div className="flex">
          <span className="font-medium w-24 text-gray-600">Grau:</span>
          <span className="font-medium">{process.grau}</span>
        </div>
        {process.instancia && (
          <div className="flex">
            <span className="font-medium w-24 text-gray-600">Instância:</span>
            <span>{process.instancia}ª Instância</span>
          </div>
        )}
        {process.origem && process.origem !== process.orgaoJulgador && (
          <div className="flex">
            <span className="font-medium w-24 text-gray-600">Origem:</span>
            <span>{process.origem}</span>
          </div>
        )}
        {process.competencia && (
          <div className="flex">
            <span className="font-medium w-24 text-gray-600">Competência:</span>
            <span>{process.competencia}</span>
          </div>
        )}
        {process.localProcessamento && (
          <div className="flex">
            <span className="font-medium w-24 text-gray-600">Local:</span>
            <span>{process.localProcessamento}</span>
          </div>
        )}
      </div>
    </div>
  );
};
