
import { Hash } from 'lucide-react';
import { ProcessData } from '@/types/process';

interface ProcessIdentificationProps {
  process: ProcessData;
}

export const ProcessIdentification = ({ process }: ProcessIdentificationProps) => {
  return (
    <div className="space-y-4">
      <h4 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
        <Hash className="h-4 w-4" />
        Identificação
      </h4>
      <div className="space-y-2 text-sm">
        <div className="flex">
          <span className="font-medium w-24 text-gray-600">Número:</span>
          <span className="font-mono text-blue-700">{process.numero}</span>
        </div>
        <div className="flex">
          <span className="font-medium w-24 text-gray-600">Classe:</span>
          <span>{process.classe}</span>
        </div>
        {process.dscClasse && (
          <div className="flex">
            <span className="font-medium w-24 text-gray-600">Desc. Classe:</span>
            <span className="text-xs text-gray-500">{process.dscClasse}</span>
          </div>
        )}
        <div className="flex">
          <span className="font-medium w-24 text-gray-600">Assunto:</span>
          <span>{process.assunto}</span>
        </div>
        {process.dscAssunto && (
          <div className="flex">
            <span className="font-medium w-24 text-gray-600">Desc. Assunto:</span>
            <span className="text-xs text-gray-500">{process.dscAssunto}</span>
          </div>
        )}
        {process.natureza && (
          <div className="flex">
            <span className="font-medium w-24 text-gray-600">Natureza:</span>
            <span>{process.natureza}</span>
          </div>
        )}
        {process.tipoProcesso && (
          <div className="flex">
            <span className="font-medium w-24 text-gray-600">Tipo:</span>
            <span>{process.tipoProcesso}</span>
          </div>
        )}
      </div>
    </div>
  );
};
