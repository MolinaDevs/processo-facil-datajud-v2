
import { Calendar } from 'lucide-react';
import { ProcessData } from '@/types/process';

interface ProcessDatesAndValuesProps {
  process: ProcessData;
}

export const ProcessDatesAndValues = ({ process }: ProcessDatesAndValuesProps) => {
  const formatDate = (dateString: string) => {
    if (!dateString) return 'Não informado';
    try {
      return new Date(dateString).toLocaleDateString('pt-BR');
    } catch {
      return dateString;
    }
  };

  const formatCurrency = (value: string) => {
    if (!value) return 'Não informado';
    if (value.includes('R$')) return value;
    const numValue = parseFloat(value.replace(/[^\d.,]/g, '').replace(',', '.'));
    if (isNaN(numValue)) return value;
    return `R$ ${numValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
  };

  return (
    <div className="space-y-4">
      <h4 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
        <Calendar className="h-4 w-4" />
        Datas e Valores
      </h4>
      <div className="space-y-2 text-sm">
        <div className="flex">
          <span className="font-medium w-24 text-gray-600">Ajuizamento:</span>
          <span>{formatDate(process.dataAjuizamento)}</span>
        </div>
        {process.dataDistribuicao && (
          <div className="flex">
            <span className="font-medium w-24 text-gray-600">Distribuição:</span>
            <span>{formatDate(process.dataDistribuicao)}</span>
          </div>
        )}
        {process.dataEncerramento && (
          <div className="flex">
            <span className="font-medium w-24 text-gray-600">Encerramento:</span>
            <span>{formatDate(process.dataEncerramento)}</span>
          </div>
        )}
        {process.dataHoraUltimaAtualizacao && (
          <div className="flex">
            <span className="font-medium w-24 text-gray-600">Última Atualização:</span>
            <span className="text-xs">{formatDate(process.dataHoraUltimaAtualizacao)}</span>
          </div>
        )}
        {process.valorCausa && (
          <div className="flex">
            <span className="font-medium w-24 text-gray-600">Valor da Causa:</span>
            <span className="font-semibold text-green-700">{formatCurrency(process.valorCausa)}</span>
          </div>
        )}
      </div>
    </div>
  );
};
