import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Upload, FileSpreadsheet, Loader2, X, AlertTriangle } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import * as XLSX from 'xlsx';

interface BatchUploadProps {
  onConsult: (processes: string[]) => Promise<void>;
  loading: boolean;
}

export const BatchUpload = ({ onConsult, loading }: BatchUploadProps) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [processNumbers, setProcessNumbers] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateProcessNumber = (numero: string): boolean => {
    const numeroLimpo = numero.replace(/\D/g, '');
    // Aceita números com 15-20 dígitos (mais flexível)
    return numeroLimpo.length >= 15 && numeroLimpo.length <= 20;
  };

  const formatProcessNumber = (numero: string): string => {
    const numeroLimpo = numero.replace(/\D/g, '');
    
    // Se tem exatamente 20 dígitos, formata no padrão CNJ
    if (numeroLimpo.length === 20) {
      return numeroLimpo.replace(/(\d{7})(\d{2})(\d{4})(\d{1})(\d{2})(\d{4})/, '$1-$2.$3.$4.$5.$6');
    }
    
    return numeroLimpo;
  };

  const handleFileSelect = async (file: File) => {
    if (!file.name.match(/\.(xlsx|xls|csv)$/)) {
      toast({
        title: "Formato inválido",
        description: "Por favor, selecione um arquivo Excel (.xlsx, .xls) ou CSV",
        variant: "destructive"
      });
      return;
    }

    if (file.size > 10 * 1024 * 1024) { // 10MB limit
      toast({
        title: "Arquivo muito grande",
        description: "O arquivo deve ter no máximo 10MB",
        variant: "destructive"
      });
      return;
    }

    try {
      console.log('📁 Processando arquivo:', file.name, `(${(file.size/1024/1024).toFixed(2)}MB)`);
      
      const arrayBuffer = await file.arrayBuffer();
      const workbook = XLSX.read(arrayBuffer, { type: 'array' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

      console.log('📊 Dados brutos extraídos:', jsonData.length, 'linhas');

      // Extrair números de processo de todas as colunas (mais flexível)
      const numbers: string[] = [];
      const invalidNumbers: string[] = [];
      
      for (let i = 0; i < jsonData.length; i++) {
        const row = jsonData[i] as any[];
        if (row && row.length > 0) {
          // Verifica todas as colunas da linha
          for (let j = 0; j < row.length; j++) {
            if (row[j]) {
              const cellValue = String(row[j]).trim();
              
              // Se parece com um número de processo
              if (cellValue.match(/\d{7,20}/) && cellValue.length >= 15) {
                const numeroFormatado = formatProcessNumber(cellValue);
                
                if (validateProcessNumber(cellValue)) {
                  // Evita duplicatas
                  if (!numbers.includes(numeroFormatado)) {
                    numbers.push(numeroFormatado);
                  }
                } else {
                  if (!invalidNumbers.includes(cellValue)) {
                    invalidNumbers.push(cellValue);
                  }
                }
              }
            }
          }
        }
      }

      console.log('✅ Números válidos encontrados:', numbers.length);
      console.log('❌ Números inválidos encontrados:', invalidNumbers.length);
      
      if (invalidNumbers.length > 0) {
        console.log('🔍 Primeiros números inválidos:', invalidNumbers.slice(0, 5));
      }

      if (numbers.length === 0) {
        toast({
          title: "Nenhum processo encontrado",
          description: `Não foram encontrados números de processo válidos. Números inválidos: ${invalidNumbers.length}`,
          variant: "destructive"
        });
        return;
      }

      if (numbers.length > 1000) {
        toast({
          title: "Muitos processos",
          description: "A planilha contém mais de 1000 processos. Máximo permitido: 1000",
          variant: "destructive"
        });
        return;
      }

      setProcessNumbers(numbers);
      setSelectedFile(file);
      
      toast({
        title: "Arquivo processado com sucesso",
        description: `${numbers.length} número(s) de processo encontrado(s)${invalidNumbers.length > 0 ? ` (${invalidNumbers.length} inválidos ignorados)` : ''}`
      });
      
    } catch (error) {
      console.error('Erro ao processar arquivo:', error);
      toast({
        title: "Erro ao processar arquivo",
        description: "Não foi possível ler o arquivo. Verifique o formato e tente novamente.",
        variant: "destructive"
      });
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelect(e.target.files[0]);
    }
  };

  const processFile = async () => {
    if (!selectedFile || processNumbers.length === 0) {
      toast({
        title: "Nenhum processo para consultar",
        description: "Por favor, selecione um arquivo com números de processo válidos",
        variant: "destructive"
      });
      return;
    }

    console.log('🚀 Iniciando processamento em lote de', processNumbers.length, 'processos');

    try {
      await onConsult(processNumbers);
    } catch (error) {
      console.error('Erro no processamento em lote:', error);
      toast({
        title: "Erro no processamento",
        description: "Houve problemas na consulta. Verifique os logs para mais detalhes.",
        variant: "destructive"
      });
    }
  };

  const removeFile = () => {
    setSelectedFile(null);
    setProcessNumbers([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-6">
      {/* Upload Area */}
      <Card 
        className={`border-2 border-dashed transition-colors ${
          dragActive 
            ? 'border-blue-400 bg-blue-50' 
            : 'border-gray-300 hover:border-gray-400'
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <CardContent className="flex flex-col items-center justify-center py-12">
          <FileSpreadsheet className="h-16 w-16 text-gray-400 mb-4" />
          <h3 className="text-lg font-semibold text-gray-700 mb-2">
            Faça upload da planilha
          </h3>
          <p className="text-gray-500 text-center mb-4">
            Arraste e solte o arquivo aqui ou clique para selecionar
          </p>
          <Button 
            variant="outline" 
            onClick={() => fileInputRef.current?.click()}
            className="mb-2"
          >
            <Upload className="mr-2 h-4 w-4" />
            Selecionar Arquivo
          </Button>
          <p className="text-xs text-gray-400">
            Formatos aceitos: .xlsx, .xls, .csv (máximo 10MB)
          </p>
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls,.csv"
            onChange={handleFileInput}
            className="hidden"
          />
        </CardContent>
      </Card>

      {/* Selected File */}
      {selectedFile && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <FileSpreadsheet className="h-8 w-8 text-green-600" />
                <div>
                  <p className="font-medium text-gray-900">{selectedFile.name}</p>
                  <p className="text-sm text-gray-500">
                    {(selectedFile.size / 1024 / 1024).toFixed(2)} MB - {processNumbers.length} processo(s) encontrado(s)
                  </p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={removeFile}
                className="text-red-600 hover:text-red-700"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Process Button */}
      <Button 
        onClick={processFile}
        disabled={!selectedFile || processNumbers.length === 0 || loading}
        className="w-full bg-blue-600 hover:bg-blue-700"
        size="lg"
      >
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Consultando {processNumbers.length} processo(s)...
          </>
        ) : (
          <>
            <FileSpreadsheet className="mr-2 h-4 w-4" />
            Consultar {processNumbers.length} Processo(s)
          </>
        )}
      </Button>

      {/* Warning Card */}
      <Card className="bg-yellow-50 border-yellow-200">
        <CardContent className="p-4">
          <div className="flex items-start space-x-3">
            <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
            <div>
              <h4 className="font-semibold text-yellow-800 mb-2">Melhorias Implementadas:</h4>
              <ul className="text-sm text-yellow-700 space-y-1">
                <li>• Busca mais flexível com múltiplas estratégias</li>
                <li>• Retry automático em caso de falhas</li>
                <li>• Validação melhorada de números de processo</li>
                <li>• Logs detalhados para diagnóstico</li>
                <li>• Delay adequado entre consultas (500ms)</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <h4 className="font-semibold text-blue-900 mb-2">Instruções:</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• A planilha pode conter números em qualquer coluna</li>
            <li>• Aceita formatos: 12345678901234567890 ou 1234567-89.0123.4.56.7890</li>
            <li>• Números devem ter entre 15-20 dígitos</li>
            <li>• Máximo de 1000 processos por planilha</li>
            <li>• Agora aceita arquivos CSV além de Excel</li>
            <li>• Sistema detecta automaticamente números duplicados</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
};
