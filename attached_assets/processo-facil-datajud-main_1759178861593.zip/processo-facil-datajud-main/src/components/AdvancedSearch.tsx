
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Search, 
  Filter,
  Calendar,
  Scale,
  FileText,
  Building,
  Loader2
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface AdvancedSearchProps {
  onSearch: (searchType: string, params: any) => Promise<void>;
  loading: boolean;
}

export const AdvancedSearch = ({ onSearch, loading }: AdvancedSearchProps) => {
  const [filters, setFilters] = useState({
    numeroProcesso: '',
    classeProcessual: '',
    assunto: '',
    orgaoJulgador: '',
    dataAjuizamentoInicio: '',
    dataAjuizamentoFim: '',
    tribunal: '',
    grau: '',
    situacao: ''
  });

  const [searchTerms, setSearchTerms] = useState({
    movimentacao: '',
    classe: '',
    assunto: '',
    tribunal: '',
    dataInicio: '',
    dataFim: ''
  });

  const handleAdvancedSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const activeFilters = Object.entries(filters).reduce((acc, [key, value]) => {
      if (value.trim()) {
        acc[key] = value.trim();
      }
      return acc;
    }, {} as any);

    if (Object.keys(activeFilters).length === 0) {
      toast({
        title: "Filtros necessários",
        description: "Preencha pelo menos um campo para realizar a busca",
        variant: "destructive"
      });
      return;
    }

    try {
      await onSearch('advanced', activeFilters);
    } catch (error) {
      console.error('Erro na busca avançada:', error);
    }
  };

  const handleSpecificSearch = async (searchType: string, value: string) => {
    if (!value.trim()) {
      toast({
        title: "Campo obrigatório",
        description: "Preencha o campo de busca",
        variant: "destructive"
      });
      return;
    }

    try {
      await onSearch(searchType, value.trim());
    } catch (error) {
      console.error(`Erro na busca por ${searchType}:`, error);
    }
  };

  const handleDateRangeSearch = async () => {
    if (!searchTerms.dataInicio || !searchTerms.dataFim) {
      toast({
        title: "Período obrigatório",
        description: "Preencha as datas de início e fim",
        variant: "destructive"
      });
      return;
    }

    try {
      await onSearch('dateRange', {
        startDate: searchTerms.dataInicio,
        endDate: searchTerms.dataFim
      });
    } catch (error) {
      console.error('Erro na busca por período:', error);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Filter className="h-5 w-5" />
          Busca Avançada
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="advanced" className="w-full">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="advanced">Múltiplos Filtros</TabsTrigger>
            <TabsTrigger value="movement">Movimentação</TabsTrigger>
            <TabsTrigger value="class">Classe</TabsTrigger>
            <TabsTrigger value="subject">Assunto</TabsTrigger>
            <TabsTrigger value="court">Tribunal</TabsTrigger>
            <TabsTrigger value="period">Período</TabsTrigger>
          </TabsList>

          <TabsContent value="advanced" className="space-y-4">
            <form onSubmit={handleAdvancedSearch} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="numeroProcesso">Número do Processo</Label>
                  <Input
                    id="numeroProcesso"
                    placeholder="0000000-00.0000.0.00.0000"
                    value={filters.numeroProcesso}
                    onChange={(e) => setFilters(prev => ({ ...prev, numeroProcesso: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="classeProcessual">Classe Processual</Label>
                  <Input
                    id="classeProcessual"
                    placeholder="Ex: Procedimento Comum Cível"
                    value={filters.classeProcessual}
                    onChange={(e) => setFilters(prev => ({ ...prev, classeProcessual: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="assunto">Assunto</Label>
                  <Input
                    id="assunto"
                    placeholder="Ex: Dano Material"
                    value={filters.assunto}
                    onChange={(e) => setFilters(prev => ({ ...prev, assunto: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="orgaoJulgador">Órgão Julgador</Label>
                  <Input
                    id="orgaoJulgador"
                    placeholder="Ex: 1ª Vara Cível"
                    value={filters.orgaoJulgador}
                    onChange={(e) => setFilters(prev => ({ ...prev, orgaoJulgador: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tribunal">Tribunal</Label>
                  <Input
                    id="tribunal"
                    placeholder="Ex: TJSP"
                    value={filters.tribunal}
                    onChange={(e) => setFilters(prev => ({ ...prev, tribunal: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="grau">Grau</Label>
                  <Select value={filters.grau} onValueChange={(value) => setFilters(prev => ({ ...prev, grau: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o grau" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="G1">1º Grau</SelectItem>
                      <SelectItem value="G2">2º Grau</SelectItem>
                      <SelectItem value="TR">Turma Recursal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dataInicio">Data Ajuizamento (Início)</Label>
                  <Input
                    id="dataInicio"
                    type="date"
                    value={filters.dataAjuizamentoInicio}
                    onChange={(e) => setFilters(prev => ({ ...prev, dataAjuizamentoInicio: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dataFim">Data Ajuizamento (Fim)</Label>
                  <Input
                    id="dataFim"
                    type="date"
                    value={filters.dataAjuizamentoFim}
                    onChange={(e) => setFilters(prev => ({ ...prev, dataAjuizamentoFim: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="situacao">Situação</Label>
                  <Input
                    id="situacao"
                    placeholder="Ex: Em andamento"
                    value={filters.situacao}
                    onChange={(e) => setFilters(prev => ({ ...prev, situacao: e.target.value }))}
                  />
                </div>
              </div>

              <Button type="submit" disabled={loading} className="w-full">
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Buscando...
                  </>
                ) : (
                  <>
                    <Search className="mr-2 h-4 w-4" />
                    Buscar com Filtros
                  </>
                )}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="movement" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="movimentacao">Descrição da Movimentação</Label>
              <Input
                id="movimentacao"
                placeholder="Ex: Citação, Sentença, Recurso..."
                value={searchTerms.movimentacao}
                onChange={(e) => setSearchTerms(prev => ({ ...prev, movimentacao: e.target.value }))}
              />
            </div>
            <Button 
              onClick={() => handleSpecificSearch('movement', searchTerms.movimentacao)}
              disabled={loading}
              className="w-full"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Buscando...
                </>
              ) : (
                <>
                  <FileText className="mr-2 h-4 w-4" />
                  Buscar por Movimentação
                </>
              )}
            </Button>
          </TabsContent>

          <TabsContent value="class" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="classe">Nome da Classe</Label>
              <Input
                id="classe"
                placeholder="Ex: Procedimento Comum Cível"
                value={searchTerms.classe}
                onChange={(e) => setSearchTerms(prev => ({ ...prev, classe: e.target.value }))}
              />
            </div>
            <Button 
              onClick={() => handleSpecificSearch('class', searchTerms.classe)}
              disabled={loading}
              className="w-full"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Buscando...
                </>
              ) : (
                <>
                  <Scale className="mr-2 h-4 w-4" />
                  Buscar por Classe
                </>
              )}
            </Button>
          </TabsContent>

          <TabsContent value="subject" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="assuntoSearch">Assunto</Label>
              <Input
                id="assuntoSearch"
                placeholder="Ex: Dano Material, Responsabilidade Civil..."
                value={searchTerms.assunto}
                onChange={(e) => setSearchTerms(prev => ({ ...prev, assunto: e.target.value }))}
              />
            </div>
            <Button 
              onClick={() => handleSpecificSearch('subject', searchTerms.assunto)}
              disabled={loading}
              className="w-full"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Buscando...
                </>
              ) : (
                <>
                  <FileText className="mr-2 h-4 w-4" />
                  Buscar por Assunto
                </>
              )}
            </Button>
          </TabsContent>

          <TabsContent value="court" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="tribunalSearch">Nome do Tribunal</Label>
              <Input
                id="tribunalSearch"
                placeholder="Ex: TJSP, TJRJ, TJMG..."
                value={searchTerms.tribunal}
                onChange={(e) => setSearchTerms(prev => ({ ...prev, tribunal: e.target.value }))}
              />
            </div>
            <Button 
              onClick={() => handleSpecificSearch('court', searchTerms.tribunal)}
              disabled={loading}
              className="w-full"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Buscando...
                </>
              ) : (
                <>
                  <Building className="mr-2 h-4 w-4" />
                  Buscar por Tribunal
                </>
              )}
            </Button>
          </TabsContent>

          <TabsContent value="period" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="dataInicioSearch">Data Início</Label>
                <Input
                  id="dataInicioSearch"
                  type="date"
                  value={searchTerms.dataInicio}
                  onChange={(e) => setSearchTerms(prev => ({ ...prev, dataInicio: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dataFimSearch">Data Fim</Label>
                <Input
                  id="dataFimSearch"
                  type="date"
                  value={searchTerms.dataFim}
                  onChange={(e) => setSearchTerms(prev => ({ ...prev, dataFim: e.target.value }))}
                />
              </div>
            </div>
            <Button 
              onClick={handleDateRangeSearch}
              disabled={loading}
              className="w-full"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Buscando...
                </>
              ) : (
                <>
                  <Calendar className="mr-2 h-4 w-4" />
                  Buscar por Período
                </>
              )}
            </Button>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};
