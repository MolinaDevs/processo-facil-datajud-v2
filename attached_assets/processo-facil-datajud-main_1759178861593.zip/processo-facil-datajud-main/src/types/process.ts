
export interface ProcessData {
  numero: string;
  classe: string;
  assunto: string;
  tribunal: string;
  orgaoJulgador: string;
  dataAjuizamento: string;
  situacao: string;
  movimentacoes: Array<{
    data: string;
    descricao: string;
    complemento?: string;
  }>;
  valorCausa?: string;
  segredoJustica?: boolean;
  justicaGratuita?: boolean;
  prioridade?: string;
  natureza?: string;
  grau?: string;
  origem?: string;
  dataHoraUltimaAtualizacao?: string;
  sistema?: string;
  formato?: string;
  nivelSigilo?: number;
  intervencaoMP?: boolean;
  tamanhoProcesso?: string;
  dscClasse?: string;
  dscAssunto?: string;
  magistrado?: {
    nome: string;
    codigo?: number;
  };
  serventia?: {
    codigo?: number;
    nome: string;
  };
  procurador?: Array<{
    nome: string;
    cpf?: string;
    oab?: string;
  }>;
  partes?: Array<{
    nome: string;
    tipoPessoa: string;
    polo: string;
    cpfCnpj?: string;
  }>;
  localProcessamento?: string;
  competencia?: string;
  dataDistribuicao?: string;
  dataEncerramento?: string;
  tipoProcesso?: string;
  instancia?: number;
}

export interface ConsultationStats {
  total: number;
  found: number;
  errors: string[];
}
