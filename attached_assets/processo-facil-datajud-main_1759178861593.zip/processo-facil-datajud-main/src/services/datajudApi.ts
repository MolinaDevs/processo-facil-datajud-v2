import { DataJudConfig, ProcessoDataJud, SearchFilters } from './datajud/types';
import { DataJudQueryBuilders } from './datajud/queryBuilders';
import { DataJudHttpClient } from './datajud/httpClient';
import { DataJudFormatter } from './datajud/dataFormatter';

export class DataJudService {
  private httpClient: DataJudHttpClient;

  constructor(apiKey: string) {
    const config: DataJudConfig = {
      apiKey,
      // Agora usa o proxy local em vez da URL direta
      baseUrl: '/api/datajud'
    };
    this.httpClient = new DataJudHttpClient(config);
  }

  async consultarProcesso(numeroProcesso: string): Promise<ProcessoDataJud> {
    const maxRetries = 3;
    let lastError: Error | null = null;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`Tentativa ${attempt}/${maxRetries} para processo: ${numeroProcesso}`);
        
        const query = DataJudQueryBuilders.createProcessNumberQuery(numeroProcesso);
        console.log('Query gerada:', JSON.stringify(query, null, 2));
        
        const data = await this.httpClient.executeQuery(query);
        
        console.log(`Resposta da API para ${numeroProcesso}:`, {
          total: data.hits?.total?.value || data.hits?.total || 0,
          encontrados: data.hits?.hits?.length || 0
        });
        
        if (!data.hits || !data.hits.hits || data.hits.hits.length === 0) {
          throw new Error(`Processo ${numeroProcesso} não encontrado na base de dados (tentativa ${attempt})`);
        }

        const processo = data.hits.hits[0]._source;
        console.log(`✓ Processo ${numeroProcesso} encontrado com sucesso na tentativa ${attempt}`);
        return DataJudFormatter.formatProcessoData(processo);
        
      } catch (error) {
        lastError = error as Error;
        console.error(`✗ Erro na tentativa ${attempt} para processo ${numeroProcesso}:`, error);
        
        if (attempt < maxRetries) {
          // Aguarda antes da próxima tentativa (backoff exponencial)
          const delay = Math.pow(2, attempt) * 1000; // 2s, 4s, 8s
          console.log(`Aguardando ${delay}ms antes da próxima tentativa...`);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    }

    throw lastError || new Error(`Falha após ${maxRetries} tentativas para o processo ${numeroProcesso}`);
  }

  async consultarProcessosAvancado(filters: SearchFilters): Promise<ProcessoDataJud[]> {
    try {
      const query = DataJudQueryBuilders.createAdvancedQuery(filters);
      const data = await this.httpClient.executeQuery(query);
      
      if (!data.hits || !data.hits.hits || data.hits.hits.length === 0) {
        return [];
      }

      return data.hits.hits.map((hit: any) => DataJudFormatter.formatProcessoData(hit._source));
    } catch (error) {
      console.error('Erro na consulta avançada:', error);
      throw error;
    }
  }

  async consultarPorMovimentacao(movementDescription: string): Promise<ProcessoDataJud[]> {
    try {
      const query = DataJudQueryBuilders.createMovementQuery(movementDescription);
      const data = await this.httpClient.executeQuery(query);
      
      if (!data.hits || !data.hits.hits || data.hits.hits.length === 0) {
        return [];
      }

      return data.hits.hits.map((hit: any) => DataJudFormatter.formatProcessoData(hit._source));
    } catch (error) {
      console.error('Erro na consulta por movimentação:', error);
      throw error;
    }
  }

  async consultarPorClasse(className: string): Promise<ProcessoDataJud[]> {
    try {
      const query = DataJudQueryBuilders.createClassQuery(className);
      const data = await this.httpClient.executeQuery(query);
      
      if (!data.hits || !data.hits.hits || data.hits.hits.length === 0) {
        return [];
      }

      return data.hits.hits.map((hit: any) => DataJudFormatter.formatProcessoData(hit._source));
    } catch (error) {
      console.error('Erro na consulta por classe:', error);
      throw error;
    }
  }

  async consultarPorAssunto(subject: string): Promise<ProcessoDataJud[]> {
    try {
      const query = DataJudQueryBuilders.createSubjectQuery(subject);
      const data = await this.httpClient.executeQuery(query);
      
      if (!data.hits || !data.hits.hits || data.hits.hits.length === 0) {
        return [];
      }

      return data.hits.hits.map((hit: any) => DataJudFormatter.formatProcessoData(hit._source));
    } catch (error) {
      console.error('Erro na consulta por assunto:', error);
      throw error;
    }
  }

  async consultarPorTribunal(courtName: string): Promise<ProcessoDataJud[]> {
    try {
      const query = DataJudQueryBuilders.createCourtQuery(courtName);
      const data = await this.httpClient.executeQuery(query);
      
      if (!data.hits || !data.hits.hits || data.hits.hits.length === 0) {
        return [];
      }

      return data.hits.hits.map((hit: any) => DataJudFormatter.formatProcessoData(hit._source));
    } catch (error) {
      console.error('Erro na consulta por tribunal:', error);
      throw error;
    }
  }

  async consultarPorPeriodo(startDate: string, endDate: string): Promise<ProcessoDataJud[]> {
    try {
      const query = DataJudQueryBuilders.createDateRangeQuery(startDate, endDate);
      const data = await this.httpClient.executeQuery(query);
      
      if (!data.hits || !data.hits.hits || data.hits.hits.length === 0) {
        return [];
      }

      return data.hits.hits.map((hit: any) => DataJudFormatter.formatProcessoData(hit._source));
    } catch (error) {
      console.error('Erro na consulta por período:', error);
      throw error;
    }
  }

  async consultarProcessosLote(numerosProcessos: string[]): Promise<ProcessoDataJud[]> {
    const resultados: ProcessoDataJud[] = [];
    const erros: string[] = [];
    const totalProcessos = numerosProcessos.length;
    
    console.log(`🔍 Iniciando consulta em lote para ${totalProcessos} processos`);
    console.log('📋 Primeiros 10 números:', numerosProcessos.slice(0, 10));
    
    for (let i = 0; i < numerosProcessos.length; i++) {
      const numero = numerosProcessos[i];
      const progresso = i + 1;
      
      try {
        console.log(`📝 [${progresso}/${totalProcessos}] Consultando: ${numero}`);
        
        const processo = await this.consultarProcesso(numero);
        resultados.push(processo);
        
        console.log(`✅ [${progresso}/${totalProcessos}] Sucesso: ${numero}`);
        
        // Delay mais longo entre consultas para evitar rate limiting
        if (i < numerosProcessos.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 500)); // 500ms entre consultas
        }
        
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
        console.error(`❌ [${progresso}/${totalProcessos}] Erro para ${numero}:`, errorMessage);
        erros.push(`${numero}: ${errorMessage}`);
        
        // Delay menor em caso de erro
        await new Promise(resolve => setTimeout(resolve, 200));
      }
      
      // Log de progresso a cada 50 processos
      if (progresso % 50 === 0) {
        console.log(`📊 Progresso: ${progresso}/${totalProcessos} - Sucessos: ${resultados.length}, Erros: ${erros.length}`);
      }
    }
    
    console.log(`🏁 Consulta em lote finalizada:`);
    console.log(`   Total processados: ${totalProcessos}`);
    console.log(`   Sucessos: ${resultados.length} (${((resultados.length/totalProcessos)*100).toFixed(1)}%)`);
    console.log(`   Erros: ${erros.length} (${((erros.length/totalProcessos)*100).toFixed(1)}%)`);
    
    if (erros.length > 0) {
      console.warn('❗ Resumo dos erros mais comuns:');
      const errorCounts = erros.reduce((acc, error) => {
        const errorType = error.split(':')[1]?.trim() || 'Erro desconhecido';
        acc[errorType] = (acc[errorType] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
      
      Object.entries(errorCounts)
        .sort(([,a], [,b]) => b - a)
        .slice(0, 5)
        .forEach(([errorType, count]) => {
          console.warn(`   ${errorType}: ${count} ocorrências`);
        });
    }
    
    return resultados;
  }
}

// Re-export types for backward compatibility
export type { ProcessoDataJud, SearchFilters } from './datajud/types';
