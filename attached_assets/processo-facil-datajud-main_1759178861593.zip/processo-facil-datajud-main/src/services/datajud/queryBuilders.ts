import { SearchFilters } from './types';

export class DataJudQueryBuilders {
  static formatProcessNumber(numeroProcesso: string): string {
    // Remove todos os caracteres não numéricos
    const numeroLimpo = numeroProcesso.replace(/\D/g, '');
    
    // Se tem 20 dígitos, formata no padrão CNJ
    if (numeroLimpo.length === 20) {
      return numeroLimpo.replace(/(\d{7})(\d{2})(\d{4})(\d{1})(\d{2})(\d{4})/, '$1-$2.$3.$4.$5.$6');
    }
    
    return numeroLimpo;
  }

  static createProcessNumberQuery(numeroProcesso: string) {
    const numeroLimpo = this.formatProcessNumber(numeroProcesso);
    const numeroSomenteDigitos = numeroProcesso.replace(/\D/g, '');
    
    return {
      query: {
        bool: {
          should: [
            // Busca pelo número formatado
            { match: { numeroProcesso: numeroLimpo } },
            { match: { numeroSequencial: numeroLimpo } },
            // Busca pelos dígitos apenas
            { match: { numeroProcesso: numeroSomenteDigitos } },
            { match: { numeroSequencial: numeroSomenteDigitos } },
            // Busca com wildcard para casos de formatação diferente
            { wildcard: { numeroProcesso: `*${numeroSomenteDigitos}*` } },
            { wildcard: { numeroSequencial: `*${numeroSomenteDigitos}*` } },
            // Busca com match_phrase para sequências exatas
            { match_phrase: { numeroProcesso: numeroLimpo } },
            { match_phrase: { numeroSequencial: numeroLimpo } }
          ],
          minimum_should_match: 1
        }
      },
      sort: [{ "@timestamp": { order: "desc" } }],
      size: 10
    };
  }

  static createAdvancedQuery(filters: SearchFilters) {
    const mustQueries: any[] = [];

    if (filters.numeroProcesso) {
      mustQueries.push({
        bool: {
          should: [
            { match: { numeroProcesso: this.formatProcessNumber(filters.numeroProcesso) } },
            { match: { numeroSequencial: this.formatProcessNumber(filters.numeroProcesso) } }
          ]
        }
      });
    }

    if (filters.classeProcessual) {
      mustQueries.push({
        bool: {
          should: [
            { match: { "classe.nome": filters.classeProcessual } },
            { match: { dscClasse: filters.classeProcessual } }
          ]
        }
      });
    }

    if (filters.assunto) {
      mustQueries.push({
        bool: {
          should: [
            {
              nested: {
                path: "assuntos",
                query: {
                  match: {
                    "assuntos.nome": filters.assunto
                  }
                }
              }
            },
            { match: { dscAssunto: filters.assunto } }
          ]
        }
      });
    }

    if (filters.orgaoJulgador) {
      mustQueries.push({
        bool: {
          should: [
            { match: { "orgaoJulgador.nome": filters.orgaoJulgador } },
            { match: { "orgaoJulgador.nomeOrgao": filters.orgaoJulgador } },
            { match: { origem: filters.orgaoJulgador } }
          ]
        }
      });
    }

    if (filters.tribunal) {
      mustQueries.push({
        bool: {
          should: [
            { match: { "tribunal.nome": filters.tribunal } },
            { match: { "tribunal_.nome": filters.tribunal } },
            { match: { tribunal: filters.tribunal } }
          ]
        }
      });
    }

    if (filters.grau) {
      mustQueries.push({
        match: {
          grau: filters.grau
        }
      });
    }

    if (filters.situacao) {
      mustQueries.push({
        bool: {
          should: [
            { match: { "dadosBasicos.situacao": filters.situacao } },
            { match: { situacao: filters.situacao } }
          ]
        }
      });
    }

    // Filtro por período de ajuizamento
    if (filters.dataAjuizamentoInicio || filters.dataAjuizamentoFim) {
      const rangeQuery: any = {};
      if (filters.dataAjuizamentoInicio) {
        rangeQuery.gte = filters.dataAjuizamentoInicio;
      }
      if (filters.dataAjuizamentoFim) {
        rangeQuery.lte = filters.dataAjuizamentoFim;
      }
      
      mustQueries.push({
        range: {
          dataAjuizamento: rangeQuery
        }
      });
    }

    return {
      query: {
        bool: {
          must: mustQueries.length > 0 ? mustQueries : [{ match_all: {} }]
        }
      },
      sort: [{ "@timestamp": { order: "desc" } }],
      size: 100
    };
  }

  static createMovementQuery(movementDescription: string) {
    return {
      query: {
        nested: {
          path: "movimentos",
          query: {
            bool: {
              should: [
                {
                  match: {
                    "movimentos.nome": movementDescription
                  }
                },
                {
                  match: {
                    "movimentos.complemento": movementDescription
                  }
                }
              ]
            }
          }
        }
      },
      sort: [{ "@timestamp": { order: "desc" } }],
      size: 50
    };
  }

  static createClassQuery(className: string) {
    return {
      query: {
        match: {
          "classe.nome": className
        }
      },
      sort: [{ "@timestamp": { order: "desc" } }],
      size: 50
    };
  }

  static createSubjectQuery(subject: string) {
    return {
      query: {
        nested: {
          path: "assuntos",
          query: {
            match: {
              "assuntos.nome": subject
            }
          }
        }
      },
      sort: [{ "@timestamp": { order: "desc" } }],
      size: 50
    };
  }

  static createCourtQuery(courtName: string) {
    return {
      query: {
        match: {
          "tribunal_.nome": courtName
        }
      },
      sort: [{ "@timestamp": { order: "desc" } }],
      size: 50
    };
  }

  static createDateRangeQuery(startDate: string, endDate: string) {
    return {
      query: {
        range: {
          dataAjuizamento: {
            gte: startDate,
            lte: endDate
          }
        }
      },
      sort: [{ "dataAjuizamento": { order: "desc" } }],
      size: 100
    };
  }
}
