
import { ProcessoDataJud } from './types';

export class DataJudFormatter {
  static formatProcessoData(data: any): ProcessoDataJud {
    console.log('Dados completos recebidos da API:', data);
    
    // Mapeamento correto conforme documentação DataJud
    const tribunalInfo = data.tribunal || data.orgaoJulgador || {};
    const orgaoJulgadorInfo = data.orgaoJulgador || data.tribunal || {};
    
    return {
      numeroSequencial: data.numeroProcesso || data.numeroSequencial || '',
      digitoVerificador: data.digitoVerificador || '',
      ano: data.ano || '',
      segmentoPoderJudiciario: data.segmentoPoderJudiciario || '',
      tribunal: tribunalInfo.nome || tribunalInfo.codigo || data.tribunal || '',
      origem: data.origem || '',
      classe: {
        codigo: data.classe?.codigo || 0,
        nome: data.classe?.nome || data.dscClasse || 'Não informado'
      },
      sistema: {
        codigo: data.sistema?.codigo || 0,
        nome: data.sistema?.nome || 'Não informado'
      },
      formato: {
        codigo: data.formato?.codigo || 0,
        nome: data.formato?.nome || 'Não informado'
      },
      tribunal_: {
        codigo: tribunalInfo.codigo || 0,
        nome: tribunalInfo.nome || data.tribunal || 'Não informado'
      },
      dataHoraUltimaAtualizacao: data.dataHoraUltimaAtualizacao || '',
      grau: data.grau || '',
      dataAjuizamento: data.dataAjuizamento || '',
      movimentos: data.movimentos || [],
      assuntos: data.assuntos || [],
      dadosBasicos: {
        situacao: data.dadosBasicos?.situacao || data.situacao || 'Não informado',
        polo: data.dadosBasicos?.polo || data.polo || '',
        procedimento: data.dadosBasicos?.procedimento || data.procedimento || '',
        competencia: data.dadosBasicos?.competencia || data.competencia || '',
        classeProcessual: data.dadosBasicos?.classeProcessual || data.classeProcessual || '',
        assunto: data.dadosBasicos?.assunto || data.assunto || ''
      },
      // Mapeamento correto do valor da causa conforme documentação
      valorCausa: data.valorCausa || data.valorDaCausa || '',
      segredoJustica: data.segredoJustica || false,
      justicaGratuita: data.justicaGratuita || false,
      prioridade: data.prioridade || '',
      natureza: data.natureza || '',
      outroParametro: data.outroParametro || '',
      nivelSigilo: data.nivelSigilo || 0,
      intervencaoMP: data.intervencaoMP || false,
      tamanhoProcesso: data.tamanhoProcesso || '',
      dscClasse: data.dscClasse || data.classe?.nome || '',
      dscAssunto: data.dscAssunto || data.assuntos?.[0]?.nome || '',
      // Mapeamento correto do órgão julgador conforme documentação
      orgaoJulgador: orgaoJulgadorInfo ? {
        codigo: orgaoJulgadorInfo.codigo || 0,
        nome: orgaoJulgadorInfo.nome || orgaoJulgadorInfo.nomeOrgao || data.origem || 'Não informado',
        instancia: orgaoJulgadorInfo.instancia || this.determinarInstancia(data.grau)
      } : undefined,
      magistrado: data.magistrado ? {
        nome: data.magistrado.nome || 'Não informado',
        codigo: data.magistrado.codigo || 0
      } : undefined,
      serventia: data.serventia ? {
        codigo: data.serventia.codigo || 0,
        nome: data.serventia.nome || 'Não informado'
      } : undefined,
      procurador: data.procurador || [],
      partes: data.partes || [],
      localProcessamento: data.localProcessamento || '',
      competencia: data.competencia || data.dadosBasicos?.competencia || '',
      dataDistribuicao: data.dataDistribuicao || '',
      dataEncerramento: data.dataEncerramento || '',
      tipoProcesso: data.tipoProcesso || '',
      instancia: data.instancia || this.determinarInstancia(data.grau)
    };
  }

  private static determinarInstancia(grau: string): number {
    if (grau === 'G1') return 1;
    if (grau === 'G2') return 2;
    if (grau === 'G3') return 3;
    return 0;
  }
}
