
import { DataJudConfig } from './types';

export class DataJudHttpClient {
  private config: DataJudConfig;

  constructor(config: DataJudConfig) {
    this.config = config;
  }

  async executeQuery(query: any): Promise<any> {
    try {
      console.log('Executando query:', JSON.stringify(query, null, 2));
      
      // Usar o proxy local em vez da URL direta da API
      const proxyUrl = '/api/datajud';
      console.log('URL do proxy:', proxyUrl);
      
      const response = await fetch(proxyUrl, {
        method: 'POST',
        headers: {
          'Authorization': `APIKey ${this.config.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(query)
      });

      console.log('Status da resposta:', response.status);
      console.log('Headers da resposta:', Object.fromEntries(response.headers.entries()));
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: 'Erro desconhecido' }));
        console.error('Erro do proxy:', errorData);
        throw new Error(errorData.error || `Erro no servidor: ${response.status} - ${response.statusText}`);
      }

      const data = await response.json();
      
      console.log('Resposta da API parseada:', {
        total: data.hits?.total,
        encontrados: data.hits?.hits?.length || 0,
        temErros: !!data.error
      });

      // Verificar se a resposta da API contém erros
      if (data.error) {
        console.error('Erro retornado pela API:', data.error);
        throw new Error(`Erro da API DataJud: ${data.error.type || 'Erro desconhecido'} - ${data.error.reason || 'Sem detalhes'}`);
      }
      
      return data;
    } catch (error) {
      console.error('Erro ao executar query:', error);
      throw error;
    }
  }
}
