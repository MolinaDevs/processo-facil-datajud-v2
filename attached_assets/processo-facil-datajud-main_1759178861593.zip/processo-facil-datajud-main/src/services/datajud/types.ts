
export interface DataJudConfig {
  apiKey: string;
  baseUrl: string;
}

export interface ProcessoDataJud {
  numeroSequencial: string;
  digitoVerificador: string;
  ano: string;
  segmentoPoderJudiciario: string;
  tribunal: string;
  origem: string;
  classe: {
    codigo: number;
    nome: string;
  };
  sistema: {
    codigo: number;
    nome: string;
  };
  formato: {
    codigo: number;
    nome: string;
  };
  tribunal_: {
    codigo: number;
    nome: string;
  };
  dataHoraUltimaAtualizacao: string;
  grau: string;
  dataAjuizamento: string;
  movimentos: Array<{
    codigo: number;
    nome: string;
    dataHora: string;
    complementoTabelado?: {
      codigo: number;
      nome: string;
      descricao: string;
    };
    complemento?: string;
  }>;
  assuntos: Array<{
    codigo: number;
    nome: string;
    principal: boolean;
  }>;
  dadosBasicos: {
    situacao: string;
    polo?: string;
    procedimento?: string;
    competencia?: string;
    classeProcessual?: string;
    assunto?: string;
  };
  // Campos adicionais baseados no glossário DataJud
  valorCausa?: string;
  segredoJustica?: boolean;
  justicaGratuita?: boolean;
  prioridade?: string;
  natureza?: string;
  outroParametro?: string;
  nivelSigilo?: number;
  intervencaoMP?: boolean;
  tamanhoProcesso?: string;
  dscClasse?: string;
  dscAssunto?: string;
  orgaoJulgador?: {
    codigo: number;
    nome: string;
    instancia?: number;
  };
  magistrado?: {
    nome: string;
    codigo?: number;
  };
  serventia?: {
    codigo: number;
    nome: string;
  };
  procurador?: Array<{
    nome: string;
    cpf?: string;
    oab?: string;
  }>;
  partes?: Array<{
    nome: string;
    tipoPessoa: string;
    polo: string;
    cpfCnpj?: string;
  }>;
  localProcessamento?: string;
  competencia?: string;
  dataDistribuicao?: string;
  dataEncerramento?: string;
  tipoProcesso?: string;
  instancia?: number;
}

export interface SearchFilters {
  numeroProcesso?: string;
  classeProcessual?: string;
  assunto?: string;
  orgaoJulgador?: string;
  dataAjuizamentoInicio?: string;
  dataAjuizamentoFim?: string;
  tribunal?: string;
  grau?: string;
  situacao?: string;
}
